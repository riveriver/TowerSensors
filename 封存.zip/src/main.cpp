#include <Arduino.h>
#include <SoftwareSerial.h>
#include "RTC_Alarm.h"
#include "SLED.h"
#include <Adafruit_GPS.h>
#include "GPS_UM982.h"
#include "IMU_HWT9073.h"
#include "TowerComm.h"
#include <Wire.h>
#include <Adafruit_I2CDevice.h>

#define Version "2.0.0"
DateTime sleep_time(24,5,7,17,05,01); 
DateTime alarm_time(24,5,7,9,05,01); 
#define RTC_ADDR 0x75
#ifdef ONLY_IMU
#define IMU_ADDR 0x50
#else
#define IMU_ADDR 0x55
#endif
#define RTC_WAKEUP_IO GPIO_NUM_7
RTC_DATA_ATTR int bootCount = 0;
RTC_DATA_ATTR int bootFlag = false;
RTC_Alarm rtc_alarm;
TwoWire wire_0 = TwoWire(0);
DateTime now_time;

ICACHE_RAM_ATTR void alarm_interrupt()
{
	Serial.println("alarm_interrupt !");
};

uint8_t example_comm_data[12] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF};

// IMU_HWT9073结构问题使用类不方便，故不使用
// IMU_HWT9073 imu;
String str_quat = "";
ImuCommFrame imu_comm;
GPS_UM982 gps;
GpsCommFrame gps_comm;
uint8_t example_gps_frame[38] = {0xFC, 0x20, 0x01, 0x7B, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x3F,
								 0x33, 0x33, 0xF1, 0x42, 0x00, 0x00, 0x00, 0x00, 0x9A, 0x99, 0xF5, 0x41, 0x41, 0x1A, 0x0B, 0x45,
								 0x09, 0x52, 0x32, 0x46, 0x01, 0x01, 0x11, 0x00, 0xBA, 0x37};
void pack_gps_comm_frame()
{
	now_time = rtc_alarm.now();
	gps_comm.time.hour = now_time.hour();
	gps_comm.time.minute = now_time.minute();
	gps_comm.time.second = now_time.second();
	
	gps_comm.hdop = gps.HDOP;
	// gps_comm.sol_status = gps.sol;
	// gps_comm.satellites = gps.satellites;
	gps_comm.latitude = gps.latitude;
	// if (gps.lat == 'N')
	// {
	// 	gps_comm.lat_ns = 1;
	// }
	// else if (gps.lat == 'S')
	// {
	// 	gps_comm.lat_ns = 2;
	// }
	gps_comm.longitude = gps.longitude;
	// if (gps.lon == 'E')
	// {
	// 	gps_comm.lon_ew = 1;
	// }
	// else if (gps.lon == 'W')
	// {
	// 	gps_comm.lon_ew = 2;
	// }
	gps_comm.heading = 120.6;
	gps_comm.pitch = 0;
	gps_comm.roll = 30.7;
}

void initSystem()
{
	Serial.begin(115200);
Serial.printf("VERSION:%s;BUILD_FLAGS:",Version);
#ifdef DEBUG_MODE
	Serial.printf("DEBUG_MODE,");
#else
	Serial.printf("COMMON_MODE,");
#endif
#ifdef LIVE_ALWAY
	Serial.printf("LIVE_ALWAY,");
#endif
#ifdef ONLY_IMU
	Serial.printf("ONLY_IMU,");
#endif
#ifdef TEST_IMU
	Serial.printf("TEST_IMU,");
#endif
#ifdef TEST_GPS
	Serial.printf("TEST_GPS,");
#endif
#ifdef TEST_RTC
	Serial.printf("TEST_RTC,");
#endif
	Serial.println("");
	// EN 18V
	pinMode(34, OUTPUT);
	digitalWrite(34, LOW);
	Serial.println("ENABLE 18V(IO34 LOW)");
	// EN 5V 
	pinMode(33, OUTPUT);
	digitalWrite(33, HIGH);
	Serial.println("ENABLE 5V (IO33 HIGH)");
    // EN_SD
	pinMode(14, OUTPUT);
	digitalWrite(14, HIGH);
	Serial.println("EN_SD(IO_14 HIGH)");
	/* TowerBoard-v2.0 end */

}

void setup()
{
	initSystem();
/* RTC */
	if (wire_0.begin(8, 9, 400000U) == false)
	{
		Serial.println("[ERROR]wire_0 begin fail!!!");
	}
	if (rtc_alarm.init(&wire_0) == false)
	{
		Serial.println("[ERROR]rtc begin fail!!!");
	}
	interrupts();
	attachInterrupt(digitalPinToInterrupt(RTC_WAKEUP_IO), alarm_interrupt, FALLING);
	pinMode(RTC_WAKEUP_IO, INPUT_PULLUP);
	esp_sleep_enable_ext0_wakeup(RTC_WAKEUP_IO, 0);
/* 从网络时间服务器上获取并设置时间,获取成功后芯片会使用RTC时钟保持时间的更新(need wifi)*/
	// const char *ntpServer = "pool.ntp.org";
	// const long gmtOffset_sec = 8 * 3600;
	// const int daylightOffset_sec = 0;
    // configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
	rtc_alarm.clearAlarm(1); 
	rtc_alarm.disableAlarm(1);
	// 设置并启用闹钟时间
	if(rtc_alarm.setAlarm1(alarm_time,DS3231_A1_Hour) == false){
		Serial.printf("[ERROR]setAlarm1 fail!!!\n"); 
	}  
	// if (++bootCount != 1)
	// {
		rtc_alarm.print_wakeup_reason();
	// }
	// else{
	// 	rtc_alarm.adjust(DateTime(F(__DATE__),F(__TIME__)));
	// }
	delay(200);
#ifndef ONLY_IMU
	gps.init();
#endif
	Imu_initHwt9073(IMU_ADDR);
	InitRadio();
/* Serial_Log */
	Serial.printf("boot count:%d\n", bootCount);
	now_time = rtc_alarm.now();
	Serial.printf("wakeup_time:%02d:%02d:%02d\n",
				  now_time.hour(), now_time.minute(), now_time.second());
	alarm_time = rtc_alarm.getAlarm1();
	Serial.printf("next_alarm_time:%02d:%02d:%02d\n",
			alarm_time.hour(), alarm_time.minute(), alarm_time.second());
	Serial.printf("next_sleep_time:%02d:%02d:%02d\n",
			sleep_time.hour(), sleep_time.minute(), sleep_time.second());
}

void loop()
{
#ifdef TEST_IMU
   test_raw_send_receive();
#else
	test_receive_parse(IMU_ADDR);
#endif
    now_time = rtc_alarm.now();
	imu_comm.time.hour = now_time.hour();
	imu_comm.time.minute = now_time.minute();
	imu_comm.time.second = now_time.second();
	for (int i = 0; i < 4; i++)
	{
		imu_comm.quat[i] = quat_raw[i];
	}
	SendToUpper((uint8_t *)&imu_comm, sizeof(imu_comm), 0x02);
	for (int i = 0; i < 4; i++)
	{
		imu_comm.quat[i] = quat_raw[i];
	}
	SendToUpper((uint8_t *)&imu_comm, sizeof(imu_comm), 0x02);
#ifdef DEBUG_MODE
 	Serial.printf("0X%X:%f,%f,%f,%f\n\r",IMU_ADDR,quat_raw[0],quat_raw[1],quat_raw[2],quat_raw[3]);
#endif

#ifdef TEST_RTC
	if (bootFlag == false)
	{
		bootFlag = true;
		now_time = rtc_alarm.now();
#ifdef DEBUG_MODE
		Serial.printf("[TEST]sleep time:%02d:%02d:%02d\n",
					now_time.hour(), now_time.minute(), now_time.second());
#endif
		delay(500);
		digitalWrite(34, HIGH);
		digitalWrite(33, LOW);
		delay(500);
		esp_deep_sleep_start();
	}
#else
#ifndef LIVE_ALWAY
	now_time = rtc_alarm.now();
	// Serial_Log.printf("now_time:%02d:%02d:%02d\n",
	// 	now_time.hour(), now_time.minute(), now_time.second());
	if (now_time.hour() >= sleep_time.hour() && now_time.minute() >= sleep_time.minute())
	{
		// Serial_Log.printf("\nauto_sleep_time:%02d:%02d:%02d\n",
		// 	now_time.hour(), now_time.minute(), now_time.second());
		// delay(10);
		Serial.printf("auto_sleep_time:%02d:%02d:%02d\n",
			now_time.hour(), now_time.minute(), now_time.second());
		delay(100);
		digitalWrite(34, HIGH);
		digitalWrite(33, LOW);
		delay(100);
		esp_deep_sleep_start();
	}
#endif 
#endif
// Serial.printf("GPS_START:%d\n",millis());
#ifndef ONLY_IMU
#ifdef TEST_GPS
	gps.test_Parse();
#else
	gps.update();
#endif
// if (gps.latitude != 0 && gps.longitude != 0)
// {
	// Serial_Log.println(gps.OutputGpsInfo());
	pack_gps_comm_frame();
	SendToUpper((uint8_t *)&gps_comm, sizeof(gps_comm), 0x01);
// }else{
//     Serial.println("GPS data Invaild");
// }
#endif
}